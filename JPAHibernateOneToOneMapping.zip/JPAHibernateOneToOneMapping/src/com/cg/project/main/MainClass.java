package com.cg.project.main;

import javax.persistence.EntityManagerFactory;

import com.cg.project.beans.Car;
import com.cg.project.beans.Customer;
import com.cg.project.util.EntityManagerFactoryProvider;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();
	}

}
