package com.cg.project.main;

import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;

public class MainClass {

	public static void main(String[] args) {
		AssociateDAO dao=new AssociateDAOImpl();
		Associate associate=new Associate(1500, "Anmol", "Kaur", "xyz", "abc", "EWQ123", "anmol@gmail.com", new BankDetails(101, "hdfc", "hdfc007"), new Salary(1000,200,500));
	
		System.out.println(dao.save(associate));
		//System.out.println(dao.save(associate1));
		System.out.println(dao.findOne(1));
		//System.out.println(dao.findAll());

	}
}
