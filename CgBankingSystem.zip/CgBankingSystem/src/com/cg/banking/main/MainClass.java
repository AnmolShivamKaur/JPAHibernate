package com.cg.banking.main;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		BankingServices services=new BankingServicesImpl();
		try {
			//services.openAccount("Savings", 8000,1234,"Active");
			//services.openAccount("Current", 5000, 2345, "Active");
			//services.openAccount("Current", 10000,6785,"Active");
			/*services.depositAmount(2345, 5000);
			services.withdrawAmount(6785, 1000, 2345);*/
			
			System.out.println(services.accountStatus(1234));
			System.out.println(services.getAccountAllTransaction(1234).toString());
		} catch (BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
