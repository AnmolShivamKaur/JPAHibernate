package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.ConnectionProvider;



public class AccountDaoImpl implements AccountDAO{
	private Connection conn=ConnectionProvider.getDBConnection();

	@Override
	public Account saveAccountDetails(Account account) throws SQLException {
		conn.setAutoCommit(false);
		PreparedStatement pstmt1=conn.prepareStatement("insert into account(accountNo,pinNumber,accountBalance,accountType,status) values(ACCOUNT_NO_SEQ.nextval,?,?,?,?)");
		pstmt1.setInt(1, account.getPinNumber());
		pstmt1.setFloat(2, account.getAccountBalance());
		pstmt1.setString(3, account.getAccountType());
		pstmt1.setString(4, account.getStatus());
		pstmt1.executeUpdate();
		PreparedStatement pstmt2=conn.prepareStatement("select max(accountNo) from account");
		ResultSet rs=pstmt2.executeQuery();
		rs.next();
		conn.commit();
		return null;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws SQLException {
		
			ResultSet accountrs;
			try {
				PreparedStatement pstmt1=conn.prepareStatement("select * from account where accountNo="+accountNo);
				accountrs = pstmt1.executeQuery();
				if(accountrs.next()){
					int pinNumber=accountrs.getInt("pinNumber");
					float accountBalance=accountrs.getFloat("accountBalance");
					String accountType=accountrs.getString("accountType");
					String status=accountrs.getString("status");
					Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo);
					return account;
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}	
		return null;
}

	@Override
	public ArrayList<Transaction> getAccountAllTransactionDetails(
			long accountNumber) {
		ArrayList<Transaction> transactions=new ArrayList<>();
		try {
			PreparedStatement pstmt1=conn.prepareStatement("select * from transaction where accountNo="+accountNumber);
			ResultSet transactionrs=pstmt1.executeQuery();
			while(transactionrs.next()){
				int transactionId=transactionrs.getInt("transactionId");
				float amount=transactionrs.getFloat("amount");
				String transactionType=transactionrs.getString("transactionType");
				Transaction transaction=new Transaction(transactionId, amount, transactionType);
				transactions.add(transaction);
			}
			return transactions;
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}

	@Override
	public ArrayList<Account> getAllAccountDetails() {
		try {
			ArrayList<Account> accounts=new ArrayList<>();
			PreparedStatement pstmt1=conn.prepareStatement("select * from account");
			ResultSet accountrs=pstmt1.executeQuery();
			while(accountrs.next()){
				long accountNo=accountrs.getLong("accountNo");
				int pinNumber=accountrs.getInt("pinNumber");
				float accountBalance=accountrs.getFloat("accountBalance");
				String accountType=accountrs.getString("accountType");
				String status=accountrs.getString("status");
				Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo);
				accounts.add(account);
			}
				return accounts;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getAccountStatus(long accountNo) {
		
		
		try {
			PreparedStatement pstmt1=conn.prepareStatement("select status from account where accountNo="+accountNo);
			ResultSet rs=pstmt1.executeQuery();
			rs.next();
		   String status= rs.getString("status");
		   return status;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int updateTransaction(long accountNo,float amount,String transactionType) {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("insert into transaction(transactionId,accountNo,amount,transactionType) values(transid_seq.nextval,?,?,?)");
			pstmt1.setLong(1, accountNo);
			pstmt1.setFloat(2, amount);
			pstmt1.setString(3, transactionType);
			pstmt1.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
