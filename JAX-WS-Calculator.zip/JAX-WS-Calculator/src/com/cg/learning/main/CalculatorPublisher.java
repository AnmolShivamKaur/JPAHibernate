package com.cg.learning.main;

import javax.xml.ws.Endpoint;

import com.cg.learning.webservice.Calculator;
public class CalculatorPublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://127.0.0.1:9876/cs", new Calculator());
		System.out.println("Started");
	}
}
