package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.EntityManagerFactoryProvider;

public class AccountDaoImpl implements AccountDAO{
	private EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();

	@Override
	public Account saveAccountDetails(Account account) throws SQLException {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws SQLException {
		EntityManager entityManager=factory.createEntityManager();
		return entityManager.find(Account.class,accountNo);
	}

	@Override
	public int updateTransaction(Transaction transaction) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return 0;
	}

	@Override
	public ArrayList<Transaction> getAccountAllTransactionDetails(
			long accountNumber) {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createQuery("from Transaction a");
		ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
		return list;
	}

	@Override
	public ArrayList<Account> getAllAccountDetails() {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createQuery("from Account a");
		ArrayList<Account> list=(ArrayList<Account>)query.getResultList();
		return list;
	}

	@Override
	public String getAccountStatus(long accountNo) {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createNamedQuery("getAccountStatus");
		query.setParameter("accountNo", accountNo);
		@SuppressWarnings("unchecked")
		Account account=(Account) query.getSingleResult();
		return account.getStatus();
}

	@Override
	public boolean update(Account account) throws SQLException {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	}
