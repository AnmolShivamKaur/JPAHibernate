package com.cg.banking.main;

import java.sql.SQLException;

import javax.persistence.EntityManagerFactory;

import com.cg.banking.beans.*;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.EntityManagerFactoryProvider;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, SQLException, AccountBlockedException {
		BankingServices bankingServices=new BankingServicesImpl();
		EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();
			bankingServices.openAccount("savings", 12000, 1234, "Active");
			/*System.out.println(bankingServices.getAccountDetails(1));*/
			System.out.println(bankingServices.depositAmount(1, 1200));
			System.out.println(bankingServices.getAccountAllTransaction(1));
			System.out.println(bankingServices.accountStatus(1));

		
	}

}
