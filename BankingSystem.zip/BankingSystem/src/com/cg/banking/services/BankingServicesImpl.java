package com.cg.banking.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	private AccountDAO accountDAO = new AccountDaoImpl();

	public BankingServicesImpl() {
		super();
	}

	@Override
	public long openAccount(String accountType, float initBalance,
			int pinNumber, String status) throws InvalidAmountException,
			InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(pinNumber,accountType,status,initBalance);
		try {
			accountDAO.saveAccountDetails(account);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
		Account account;
		try {
			account = getAccountDetails(accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			Transaction transaction=new Transaction(amount,"Deposit", account);
			accountDAO.update(account);
			accountDAO.updateTransaction(transaction);
		return account.getAccountBalance();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account;
		try {
			account = getAccountDetails(accountNo);
			if(account.getAccountBalance()-amount>1000&&account.getPinNumber()==pinNumber){
				account.setAccountBalance(account.getAccountBalance()-amount);
				Transaction transaction=new Transaction(amount,"Withdraw", account);
				accountDAO.update(account);
				accountDAO.updateTransaction(transaction);
			}
			else
				System.out.println("Insufficient Balance!!Withdrawal Failed");
			return account.getAccountBalance();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account1;
		try {
			account1 = getAccountDetails(accountNoTo);
			Account account2=getAccountDetails(accountNoFrom);
			if(account2.getAccountBalance()-transferAmount>1000&&account2.getPinNumber()==pinNumber){
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				accountDAO.update(account1);
				Transaction transaction1=new Transaction(transferAmount,"Deposit", account1);
				account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
				accountDAO.update(account2);
				Transaction transaction2=new Transaction(transferAmount,"Withdraw", account2);
				accountDAO.updateTransaction(transaction1);
				accountDAO.updateTransaction(transaction2);
			}
				else
					System.out.println("Insufficient Balance!!Withdrawal Failed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException,
			SQLException {
		Account account=accountDAO.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Sorry!! Account Details Not Found");
		return account;
	}

	@Override
	public ArrayList<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		return accountDAO.getAllAccountDetails();
	}

	@Override
	public ArrayList<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return accountDAO.getAccountAllTransactionDetails(accountNo);
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException {
		return accountDAO.getAccountStatus(accountNo);
	}
	
}
