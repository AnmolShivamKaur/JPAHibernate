package com.cg.payroll.main;


import java.util.ArrayList;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
public class MainClass {
	private static PayrollServices payrollServices = new PayrollServicesImpl();

	public static void main(String[] args) throws AssociateDetailNotFoundException, PayrollServicesDownException {
		PayrollServices payrollServices = new PayrollServicesImpl();
		
		System.out.println(payrollServices.acceptAssociateDetails("Anmol", "Kaur","anmol.kaur@gmail.com", "xyz", "abc", "EWQ123", 800, 1000, 500, 600, 101, "HDFC", "HDFC006"));
		System.out.println(payrollServices.getAssociateDetails(1));
		System.out.println(payrollServices.calculateNetSalary(1));
		System.out.println(payrollServices.getAllAssociateDetails());
		}
	}


