package com.cg.learning.webservice;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Client {

	public static void main(String[] args) throws Exception{
		URL url=new URL("http://localhost:9876/cs?wsdl");
		QName qname=new QName("http://webservice.learning.cg.com/","CalculatorService");
		Service service=Service.create(url,qname);
		
		CalculatorServer endPointIntf=service.getPort(CalculatorServer.class);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st number");
		int param1=sc.nextInt();
		System.out.println("Enter 2nd number");
		int param2=sc.nextInt();
	System.out.println(endPointIntf.additon(param1,param2));
	}

}
